
public class Hermite {
    public static void main(String[] args) {
        System.out.println("Les 10 premiers polyn�mes d'Hermite : ");
        Polyn�me[] hermite = new Polyn�me[10];
        hermite[0] = new Polyn�me();
        hermite[0].setMon�me(new Mon�me(1, 0));
        hermite[1] = new Polyn�me();
        hermite[1].setMon�me(new Mon�me(1, 1));
        Mon�me m1 = new Mon�me(1.0F, 1);
        for (int i = 2; i < 10; i++) {
            Mon�me m2 = new Mon�me(-i + 1, 0);
            Polyn�me terme1 = hermite[i - 1].produit(m1);
            Polyn�me terme2 = hermite[i - 2].produit(m2);
            hermite[i] = terme1.somme(terme2);
        }
        for (int i = 0; i < 10; i++) {
            System.out.println("H" + i + "(x) = " + hermite[i]);
        }
    }
}
