import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class Polyn�meTest {

    @Test
    public void testToStringPolynomeNul() {
        Polyn�me nul = new Polyn�me();
        assertEquals("0", nul.toString());
    }

    @Test
    public void testToStringPolynomeCoefficientsPositifs() {
        Polyn�me p = new Polyn�me();
        p.setMon�me(new Mon�me(8F, 4));
        p.setMon�me(new Mon�me(8F, 2));
        p.setMon�me(new Mon�me(1F, 0));
        assertEquals("8.0xe4 + 8.0xe2 + 1.0", p.toString());
    }

    @Test
    public void testToStringPolynomeCoefficientsPositifsEtN�gatifs() {
        Polyn�me p = new Polyn�me();
        p.setMon�me(new Mon�me(128F, 8));
        p.setMon�me(new Mon�me(160F, 4));
        p.setMon�me(new Mon�me(-32F, 2));
        p.setMon�me(new Mon�me(1F, 0));
        assertEquals("128.0xe8 + 160.0xe4 - 32.0xe2 + 1.0", p.toString());
    }

    @Test
    public void testToStringPolynomePremierCoefficientN�gatif() {
        Polyn�me p = new Polyn�me();
        p.setMon�me(new Mon�me(-128F, 8));
        p.setMon�me(new Mon�me(160F, 4));
        p.setMon�me(new Mon�me(-32F, 2));
        p.setMon�me(new Mon�me(1F, 0));
        assertEquals("-128.0xe8 + 160.0xe4 - 32.0xe2 + 1.0", p.toString());
    }

    @Test
    public void testGetMon�me() {
        Polyn�me p = new Polyn�me();
        p.setMon�me(new Mon�me(6F, 1));
        assertTrue(p.getMon�me(3).estNul());
        assertEquals(1, p.getMon�me(1).getExposant());
        assertEquals(6F, p.getMon�me(1).getCoefficient(), 0F);
    }

    @Test
    public void testD�rivePolyn�me() {
        Polyn�me p = new Polyn�me();
        p.setMon�me(new Mon�me(2F, 2));
        p.setMon�me(new Mon�me(6F, 1));
        p.setMon�me(new Mon�me(32F, 0));
        assertEquals("4.0x + 6.0", p.d�riv�e().toString());
    }

    @Test
    public void testSommePolyn�mes() {
        Polyn�me p = new Polyn�me();
        p.setMon�me(new Mon�me(-128F, 8));
        p.setMon�me(new Mon�me(160F, 4));
        p.setMon�me(new Mon�me(-32F, 2));
        p.setMon�me(new Mon�me(1F, 0));
        Polyn�me other = new Polyn�me();
        other.setMon�me(new Mon�me(128F, 8));
        other.setMon�me(new Mon�me(6F, 4));
        other.setMon�me(new Mon�me(33F, 3));
        assertEquals("166.0xe4 + 33.0xe3 - 32.0xe2 + 1.0",
                p.somme(other).toString());
    }

    @Test
    public void testProduitPolynomeParMonome() {
        Polyn�me p = new Polyn�me();
        p.setMon�me(new Mon�me(128F, 8));
        p.setMon�me(new Mon�me(160F, 4));
        p.setMon�me(new Mon�me(-32F, 2));
        p.setMon�me(new Mon�me(1F, 0));
        Mon�me m = new Mon�me(2F, 1);
        assertEquals("256.0xe9 + 320.0xe5 - 64.0xe3 + 2.0x",
                p.produit(m).toString());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetMon�meExposantN�gatif() {
        Polyn�me p = new Polyn�me();
        p.getMon�me(-8);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetMon�meExposantSup�rieurDegr�Max() {
        Polyn�me p = new Polyn�me();
        p.getMon�me(1000);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetMon�meExposantSup�rieurDegr�Max() {
        Polyn�me p = new Polyn�me();
        p.setMon�me(new Mon�me(128F, 2000));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testProduitExposantSup�rieurDegr�Max() {
        Polyn�me p = new Polyn�me();
        Mon�me m = new Mon�me(5, 6);
        p.setMon�me(new Mon�me(10, 98));
        p.produit(m);
    }

}
