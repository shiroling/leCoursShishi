public class Polyn�me {

    /**
     * degr� maximum du polyn�me
     */
    public static final int DEGRE_MAX = 99;
    /**
     * tableau contenant les coefficients des mon�mes du polyn�me
     */
    private float[] coefficients;

    /**
     * cr�e un polyn�me nul
     */
    public Polyn�me() {
        // cr�er le tableau des coefficients
        this.coefficients = new float[Polyn�me.DEGRE_MAX + 1];
        // mettre � 0 tous les coefficients
        for (int i = 0; i < this.coefficients.length; i++) {
            this.coefficients[i] = 0.0F;
        }
    }

    /**
     * positionne un nouveau mon�me dans un polyn�me
     * 
     * @param m mon�me � positionner dans le polyn�me
     * @throws IllegalArgumentException si l'exposant du mon�me est sup�rieur �
     *                                  DEGRE_MAX
     */
    public void setMon�me(Mon�me m) throws IllegalArgumentException {
        if (m.getExposant() > Polyn�me.DEGRE_MAX) {
            throw new IllegalArgumentException("exposant du monome trop grand "
                    + m.getExposant() + " " + m);
        }
        this.coefficients[m.getExposant()] = m.getCoefficient();
    }

    /**
     * acc�de � un mon�me du polyn�me
     * 
     * @param exposant exposant du mon�me � acc�der
     * @throws IllegalArgumentException si l'exposant du mon�me n'est pas
     *                                  compris dans [0,DEGRE_MAX]
     */
    public Mon�me getMon�me(int exposant) throws IllegalArgumentException {
        if (exposant < 0 || exposant > Polyn�me.DEGRE_MAX) {
            throw new IllegalArgumentException("exposant invalide " + exposant);
        }
        return new Mon�me(this.coefficients[exposant], exposant);
    }

    /**
     * calcule la d�riv�e d'un polyn�me
     * 
     * @return d�riv�e du polyn�me
     */
    public Polyn�me d�riv�e() {
        // � compl�ter
        return null;
    }

    /**
     * calcule la somme de deux polyn�mes
     * 
     * @param p deuxi�me polyn�me associ� � la somme
     * @return polyn�me r�sultat
     */
    public Polyn�me somme(Polyn�me p) {
        // � compl�ter
        return null;
    }

    /**
     * calcule le produit d'un polyn�me et d'un mon�me
     * 
     * @param m mon�me associ� au produit
     * 
     * @throws IllegalArgumentException si l'exposant d'un mon�me du r�sultat
     *                                  est sup�rieur � DEGRE_MAX
     * @return polyn�me produit
     */
    public Polyn�me produit(Mon�me m) throws IllegalArgumentException {
        // � compl�ter
        return null;
    }

    @Override
    public String toString() {
        String r�sultat = "";
        for (int i = this.coefficients.length - 2; i >= 0; i--) {
            if (!this.getMon�me(i).estNul()) {
                r�sultat += this.getMon�me(i);
            }
        }
        if (r�sultat.equals("")) {
            return "0";
        }
        if (r�sultat.charAt(1) == '-') {
            return "-" + r�sultat.substring(3, r�sultat.length());
        }
        return r�sultat.substring(3, r�sultat.length());
    }

}
